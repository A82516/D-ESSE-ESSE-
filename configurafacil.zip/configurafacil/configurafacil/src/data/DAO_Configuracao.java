/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Componente;
import java.sql.PreparedStatement;

/**
 *
 * @author rps
 */
public class DAO_Configuracao {
    private Connection myConn;
    
    public DAO_Configuracao(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public int adicionarConfiguracao(double preco, String modeloCarro, String emailFuncionario) {
        int idConfiguracao = 0; 
        try {
            PreparedStatement myStmt = myConn.prepareStatement("INSERT INTO Configuracao (Preco, modeloCarro, emailFuncionario) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            myStmt.setDouble(1, preco);
            myStmt.setString(2, modeloCarro);
            myStmt.setString(3, emailFuncionario);
            int rowsAffected = myStmt.executeUpdate();
            if(rowsAffected == 1) {
                ResultSet rs = myStmt.getGeneratedKeys();
                if(rs.next())
                    idConfiguracao = rs.getInt(1);
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return idConfiguracao;
    }    
    
    public void adicionarComponenteConfiguracao(int idConfiguracao, String nomeComponente){
        try {
            PreparedStatement myStmt = myConn.prepareStatement("INSERT INTO Configuracao_has_Componente (idConfiguracao, nomeComponente) VALUES(?,?)");
            myStmt.setInt(1, idConfiguracao);
            myStmt.setString(2, nomeComponente);
            myStmt.executeUpdate();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}