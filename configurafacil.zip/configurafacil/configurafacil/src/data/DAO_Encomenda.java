/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Encomenda;
import java.sql.PreparedStatement;

/**
 *
 * @author rps
 */
public class DAO_Encomenda {
    private Connection myConn;
    
    public DAO_Encomenda(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<Integer, Encomenda> getEncomendas() {
        Map<Integer, Encomenda> encomendas = new HashMap<Integer, Encomenda>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Encomenda";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Encomenda encomenda = convertRowToEncomenda(myRs);
                encomendas.put(encomenda.getIdEncomenda(), encomenda);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return encomendas;
    }
    
    public void adicionarEncomenda(int nifCliente, String nomeCliente, int contactoCliente, int idConfiguracao) {
        try {
            PreparedStatement myStmt = myConn.prepareStatement("INSERT INTO Encomenda (nifCliente, nomeCliente, contactoCliente, idConfiguracao) VALUES(?,?,?,?)");
            myStmt.setInt(1, nifCliente);
            myStmt.setString(2, nomeCliente);
            myStmt.setInt(3, contactoCliente);
            myStmt.setInt(4, idConfiguracao);
            myStmt.executeUpdate();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    private Encomenda convertRowToEncomenda(ResultSet myRs) throws SQLException {
        Encomenda componente = new Encomenda();
        try {
            int idEncomenda = myRs.getInt("idEncomenda");
            int nifCliente = myRs.getInt("nifCliente");
            String nomeCliente = myRs.getString("nomeCliente");
            int contactoCliente = myRs.getInt("contactoCliente");
            int idConfiguracao = myRs.getInt("idConfiguracao");
            componente = new Encomenda(idEncomenda, nifCliente, nomeCliente, contactoCliente, idConfiguracao);
        } catch (SQLException e) {
        }

        return componente;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}