/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Componente;
import business.Pacote;
import java.sql.PreparedStatement;

/**
 *
 * @author rps
 */
public class DAO_Pacote {
    private Connection myConn;
    
    public DAO_Pacote(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<String, Pacote> getPacotes() {
        Map<String, Pacote> pacotes = new HashMap<String, Pacote>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Pacote";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Pacote pacote = convertRowToPacote(myRs);
                pacotes.put(pacote.getNome(), pacote);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return pacotes;
    }
    
    
    public String getPacote(String tipo){
        String res = "lixo";
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Pacote WHERE nome=?");
            myStmt.setString(1, tipo);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getString("nome");
            }
        } catch (SQLException e) {
        }
        return res;
    }

    private Pacote convertRowToPacote(ResultSet myRs) throws SQLException {
        Pacote pacote = new Pacote();
        try {
            String nome = myRs.getString("Nome");
            double desconto = myRs.getDouble("Desconto");
            pacote = new Pacote(nome, desconto);
        } catch (SQLException e) {
        }

        return pacote;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}