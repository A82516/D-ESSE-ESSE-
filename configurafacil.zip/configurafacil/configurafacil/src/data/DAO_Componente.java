/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Componente;
import java.sql.PreparedStatement;

/**
 *
 * @author rps
 */
public class DAO_Componente {
    private Connection myConn;
    
    public DAO_Componente(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<String, Componente> getComponentes() {
        Map<String, Componente> componentes = new HashMap<String, Componente>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Componente";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Componente componente = convertRowToComponente(myRs);
                componentes.put(componente.getNome(), componente);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return componentes;
    }
    
    public ArrayList<Integer> getIncompatibilidades(String nome) {
        ArrayList<Integer> ret = new ArrayList<>();
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT idIncompatibilidade FROM Incompatibilidade WHERE Componente_1 = ? OR Componente_2 = ?");
            myStmt.setString(1, nome);
            myStmt.setString(2, nome);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()) {
                ret.add(myRs.getInt("idIncompatibilidade"));

            }
        } catch (SQLException e) {
        }
        return ret;
    }        
    
    public void adicionarStock(String nome, double preco, int stock, int opcional, String detalhe, String categoria) {            
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Componente WHERE nome = ?");
            myStmt.setString(1, nome);

            if(myStmt.executeQuery().next() && preco == -1) {
                myStmt = myConn.prepareStatement("UPDATE Componente SET stock = ? WHERE nome = ?");
                myStmt.setInt(1, stock);
                myStmt.setString(2, nome);
                myStmt.executeUpdate();
            }
            else if (myStmt.executeQuery().next() && preco != -1) {
                myStmt = myConn.prepareStatement("UPDATE Componente SET stock = ?, preco = ? WHERE nome = ?");
                myStmt.setInt(1, stock);
                myStmt.setDouble(2, preco);
                myStmt.setString(3, nome);
                myStmt.executeUpdate(); 
            }
            else if (myStmt.executeQuery().next() == false) {
                myStmt = myConn.prepareStatement("INSERT INTO Componente (nome,preco,stock,idPacote, idIncompativeis, idDependentes, opcional, detalhe, categoria) VALUES (?,?,?,?,?,?,?,?,?)");
                myStmt.setString(1, nome);
                myStmt.setDouble(2, preco);
                myStmt.setInt(3, stock);
                myStmt.setNull(4, 12);
                myStmt.setNull(5, 12);
                myStmt.setNull(6, 12);
                myStmt.setInt(7, opcional);
                myStmt.setString(8, detalhe);
                myStmt.setString(9, categoria);
                myStmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public String getTipo(String nome){
        String res = "lixo";
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Componente WHERE nome=?");
            myStmt.setString(1, nome);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getString("nome");
            }
        } catch (SQLException e) {
        }
        return res;
    }

    private Componente convertRowToComponente(ResultSet myRs) throws SQLException {
        Componente componente = new Componente();
        try {
            String tipo = myRs.getString("nome");
            double preco = myRs.getDouble("preco");
            int stock = myRs.getInt("stock");
            int opcional = myRs.getInt("opcional");
            String detalhe = myRs.getString("detalhe");
            String categoria = myRs.getString("categoria");
            String idPacote = myRs.getString("idPacote");
            if(myRs.wasNull()) idPacote = "";
            componente = new Componente(tipo, preco, stock, opcional, detalhe, categoria, idPacote);
        } catch (SQLException e) {
        }

        return componente;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}