/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Carro;
import java.sql.PreparedStatement;
import jdk.internal.org.objectweb.asm.Type;

/**
 *
 * @author rps
 */
public class DAO_Carro {
    private Connection myConn;
    
    public DAO_Carro(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<String, Carro> getCarros() {
        Map<String, Carro> carros = new HashMap<String, Carro>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Carro";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Carro carro = convertRowToCarro(myRs);
                carros.put(carro.getModelo(), carro);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return carros;
    }
    
    
    public void adicionarStock(String modelo, double preco, int stock) {
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Carro WHERE Modelo = ?");
            myStmt.setString(1, modelo);

            if(myStmt.executeQuery().next() && preco == -1) {
                myStmt = myConn.prepareStatement("UPDATE Carro SET stock = ? WHERE modelo = ?");
                myStmt.setInt(1, stock);
                myStmt.setString(2, modelo);
                myStmt.executeUpdate();
            }
            else if (myStmt.executeQuery().next() && preco != -1) {
                myStmt = myConn.prepareStatement("UPDATE Carro SET stock = ?, preco = ? WHERE modelo = ?");
                myStmt.setInt(1, stock);
                myStmt.setDouble(2, preco);
                myStmt.setString(3, modelo);
                myStmt.executeUpdate(); 
            }
            else if (myStmt.executeQuery().next() == false) {
                myStmt = myConn.prepareStatement("INSERT INTO Carro (modelo,preco,stock) VALUES (?,?,?)");
                myStmt.setString(1, modelo);
                myStmt.setDouble(2, preco);
                myStmt.setInt(3, stock);
                myStmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public String getModelo(String modelo){
        String res = "lixo";
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Carro WHERE modelo=?");
            myStmt.setString(1, modelo);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getString("modelo");
            }
        } catch (SQLException e) {
        }
        return res;
    }

    private Carro convertRowToCarro(ResultSet myRs) throws SQLException {
        Carro carro = new Carro();
        try {
            String tipo = myRs.getString("modelo");
            double preco = myRs.getDouble("preco");
            int stock = myRs.getInt("stock");
            carro = new Carro(tipo, preco, stock);
        } catch (SQLException e) {
        }

        return carro;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}