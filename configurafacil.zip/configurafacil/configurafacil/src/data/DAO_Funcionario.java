/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Funcionario;
import java.sql.PreparedStatement;

/**
 *
 * @author rps
 */
public class DAO_Funcionario {
    private Connection myConn;
    
    public DAO_Funcionario(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<String, Funcionario> getFuncionarios() {
        Map<String, Funcionario> funcionarios = new HashMap<String, Funcionario>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Funcionario";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Funcionario funcionario = convertRowToFuncionario(myRs);
                funcionarios.put(funcionario.getEmail(), funcionario);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return funcionarios;
    }
    
    public void registarUtilizador(String email, String password, int tipo) {
        try {
            PreparedStatement myStmt = myConn.prepareStatement("INSERT INTO Funcionario (email,palavra_passe,tipo) VALUES (?,?,?)");
            myStmt.setString(1, email);
            myStmt.setString(2, password);
            myStmt.setInt(3, tipo);
            myStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public String getEmail(String email){
        String res = "lixo";
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Funcionario WHERE email=?");
            myStmt.setString(1, email);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getString("email");
            }
        } catch (SQLException e) {
        }
        return res;
    }
    
    public String getPassword(String email){
        String res = "lixo";
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Funcionario WHERE email=?");
            myStmt.setString(1, email);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getString("palavra_passe");
            }
        } catch (SQLException e) {
        }
        return res;
    }
    
    public int getTipo(String email){
        int res = -1;
        try {
            PreparedStatement myStmt = myConn.prepareStatement("SELECT * FROM Funcionario WHERE email=?");
            myStmt.setString(1, email);
            ResultSet myRs = myStmt.executeQuery();
            while (myRs.next()){
                res = myRs.getInt("tipo");
            }
        } catch (SQLException e) {
        }
        return res;
    }

    private Funcionario convertRowToFuncionario(ResultSet myRs) throws SQLException {
        Funcionario funcionario = new Funcionario();
        try {
            String email = myRs.getString("Email");
            String password = myRs.getString("Palavra_passe");
            int tipo = myRs.getInt("Tipo");
            funcionario = new Funcionario(email, password, tipo);
        } catch (SQLException e) {
        }

        return funcionario;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}