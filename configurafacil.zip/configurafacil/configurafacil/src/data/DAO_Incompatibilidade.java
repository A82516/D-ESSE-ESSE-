/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Incompatibilidade;
import java.sql.PreparedStatement;
import jdk.internal.org.objectweb.asm.Type;

/**
 *
 * @author rps
 */
public class DAO_Incompatibilidade {
    private Connection myConn;
    
    public DAO_Incompatibilidade(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<Integer, Incompatibilidade> getIncompatibilidades() {
        Map<Integer, Incompatibilidade> incompatibilidades = new HashMap<Integer, Incompatibilidade>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Incompatibilidade";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Incompatibilidade incompatibilidade = convertRowToIncompatibilidade(myRs);
                incompatibilidades.put(incompatibilidade.getIdIncompatibilidade(), incompatibilidade);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return incompatibilidades;
    }

    private Incompatibilidade convertRowToIncompatibilidade(ResultSet myRs) throws SQLException {
        Incompatibilidade incompatibilidade = new Incompatibilidade();
        try {
            int idIncompatibilidade = myRs.getInt("idIncompatibilidade");
            String componente_1 = myRs.getString("Componente_1");
            String componente_2 = myRs.getString("Componente_2");
            incompatibilidade = new Incompatibilidade(idIncompatibilidade, componente_1, componente_2);
        } catch (SQLException e) {
        }

        return incompatibilidade;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}