package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by luismp on 27/12/17.
 */
public class Connect {

    private final static String DB = "configurafacil";
    private final static String USERNAME = "root";
    private final static String PW = "Mulan666";

    public static Connection connect() throws SQLException{

        return DriverManager.getConnection("jdbc:mysql://:3306/"+DB+"?autoReconnect=true&useSSL=false",USERNAME,PW);
       
    }

}
