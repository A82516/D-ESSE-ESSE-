/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import business.Dependencia;
import java.sql.PreparedStatement;
import jdk.internal.org.objectweb.asm.Type;

/**
 *
 * @author rps
 */
public class DAO_Dependencia {
    private Connection myConn;
    
    public DAO_Dependencia(){
        try {
            this.myConn = Connect.connect();
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public Map<Integer, Dependencia> getDependencias() {
        Map<Integer, Dependencia> dependencias = new HashMap<Integer, Dependencia>();
        Statement myStat = null;
        ResultSet myRs = null;
        String query1 = "SELECT * FROM Dependencia";
        try {
            myStat = myConn.createStatement();
            myRs = myStat.executeQuery(query1);
            while (myRs.next()) {
                Dependencia dependencia = convertRowToDependencia(myRs);
                dependencias.put(dependencia.getIdDependencia(), dependencia);
            }
        } catch (Exception e) {
        } finally {
            close(myStat, myRs);
        }
        return dependencias;
    }

    private Dependencia convertRowToDependencia(ResultSet myRs) throws SQLException {
        Dependencia dependencia = new Dependencia();
        try {
            int idDependencia = myRs.getInt("idDependencia");
            String componente = myRs.getString("Componente");
            String componente_dependente = myRs.getString("Componente_Dependente");
            dependencia = new Dependencia(idDependencia, componente, componente_dependente);
        } catch (SQLException e) {
        }

        return dependencia;
    }

    private static void close(Statement myStmt, ResultSet myRs) {
        if (myRs != null) {
            try {
                myRs.close();
            } catch (SQLException e) {
            }
        }
        if (myStmt != null) {
            try {
                myStmt.close();
            } catch (SQLException e) {
            }
        }
    }
}