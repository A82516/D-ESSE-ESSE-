package presentation;

import business.SistemaConfiguraFacil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {
        SistemaConfiguraFacil sistema = new SistemaConfiguraFacil();
        IniciarSessaoGUI f = new IniciarSessaoGUI(sistema);
        f.setVisible(true);
    }
}
