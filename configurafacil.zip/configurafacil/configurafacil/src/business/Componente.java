/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Componente {
    private String nome;
    private double preco;
    private String idPacote;
    private int stock;
    private int opcional;
    private String detalhe;
    private String categoria;
    
    public Componente() {
        this.nome = "";
        this.preco = 0;
        this.stock = 0;
        this.idPacote = "";
        this.opcional = 0;
        this.detalhe = "";
        this.categoria = "";
    }
    
    public Componente(String nome, double preco, int stock, int opcional, String detalhe, String categoria, String idPacote) {
        this.nome = nome;
        this.preco = preco;
        this.stock = stock;
        this.opcional = opcional;
        this.detalhe = detalhe;
        this.categoria = categoria;
        this.idPacote = idPacote;

    }   
    
    public String getNome() {
        return this.nome;
    }
    
    public double getPreco() {
        return this.preco;
    }
    
    public int getStock() {
        return this.stock;
    }
    
    public String getCategoria() {
        return this.categoria;
    }
    
    public String getDetalhe() {
        return this.detalhe;
    }
    
    public int getOpcional() {
        return this.opcional;
    }
    
    public String getIdPacote() {
        return this.idPacote;
    }    
 }
