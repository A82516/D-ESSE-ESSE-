/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Funcionario {
    private String email;
    private String password;
    private int tipo;
    
    public Funcionario() {
        this.email = "";
        this.password = "";
        this.tipo = 0;
    }
    
    public Funcionario(String email, String password, int tipo) {
        this.email = email;
        this.password = password;
        this.tipo = tipo;
    }   
    
    public String getEmail() {
        return this.email;
    }
 }
