/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Incompatibilidade {
    private int idIncompatibilidade;
    private String componente_1;
    private String componente_2;
    
    public Incompatibilidade() {
        this.idIncompatibilidade = 0;
        this.componente_1 = "";
        this.componente_2 = "";
    }
    
    public Incompatibilidade(int idIncompatibilidade, String componente_1, String componente_2) {
        this.idIncompatibilidade = idIncompatibilidade;
        this.componente_1 = componente_1;
        this.componente_2 = componente_2;
    }
    
    public int getIdIncompatibilidade() {
        return this.idIncompatibilidade;
    }
    
    public String getComponente1() {
        return componente_1;
    }
    
    public String getComponente2() {
        return componente_2;
    }
}
