package business;

/**
 *
 * @author rps
 */
public class Configuracao {
    private int idConfiguracao;
    private double preco;
    private String modeloCarro;
    private String emailFuncionario;
    
    public Configuracao() {
        this.idConfiguracao = 0;
        this.preco = 0;
        this.modeloCarro = "";
        this.emailFuncionario = "";
    }
    
    public Configuracao(int idConfiguracao, double preco, String modeloCarro, String emailFuncionario) {
        this.idConfiguracao = idConfiguracao;
        this.preco = preco;
        this.modeloCarro = modeloCarro;
        this.emailFuncionario = emailFuncionario;

    }   
    
    public int getIdConfiguracao() {
        return this.idConfiguracao;
    }  
    
    public double getPreco() {
        return this.preco;
    }
    
    public String modeloCarro() {
        return this.modeloCarro;
    }
    
    public String emailFuncionario() {
        return this.emailFuncionario;
    }
 }
