/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Carro {
    private String modelo;
    private double preco;
    private int stock;
    
    public Carro() {
        this.modelo = "";
        this.preco = 0;
        this.stock = 0;
    }
    
    public Carro(String modelo, double preco, int stock) {
        this.modelo = modelo;
        this.preco = preco;
        this.stock = stock;
    }   
    
    public String getModelo() {
        return this.modelo;
    }
    
    public double getPreco() {
        return this.preco;
    }
    
    public int getStock() {
        return this.stock;
    }
 }
