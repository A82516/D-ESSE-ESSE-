/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import data.DAO_Carro;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rps
 */
public class GestaoCarros {
    private DAO_Carro carDB;
    
    public GestaoCarros() {
        this.carDB = new DAO_Carro();
    }
    
    public Map<String, Carro> consultarCarros() {
        return carDB.getCarros();
    }
    
    public void adicionarStock(String nome, double preco, int stock) {
        carDB.adicionarStock(nome, preco, stock);
    }
}
