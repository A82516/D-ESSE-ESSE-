/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Pacote {
    private String nome;
    private double desconto;
    
    public Pacote() {
        this.nome = "";
        this.desconto = 0;
    }
    
    public Pacote(String nome, double desconto) {
        this.nome = nome;
        this.desconto = desconto;
    }   
    
    public String getNome() {
        return this.nome;
    }
    
    public double getDesconto() {
        return this.desconto;
    }
 }
