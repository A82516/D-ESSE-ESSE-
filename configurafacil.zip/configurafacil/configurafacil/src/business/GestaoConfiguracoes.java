/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import data.DAO_Incompatibilidade;
import data.DAO_Dependencia;
import data.DAO_Configuracao;
import data.DAO_Encomenda;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rps
 */
public class GestaoConfiguracoes {
    private DAO_Incompatibilidade incDB;
    private DAO_Dependencia depDB;
    private DAO_Configuracao confDB;
    private DAO_Encomenda encDB;
    
    public GestaoConfiguracoes() {
        this.incDB = new DAO_Incompatibilidade();
        this.depDB = new DAO_Dependencia();
        this.confDB = new DAO_Configuracao();
        this.encDB = new DAO_Encomenda();
    }
    
    public Map<Integer, Incompatibilidade> getIncompatibilidades() {
        return incDB.getIncompatibilidades();
    }
    
    public Map<Integer, Dependencia> getDependencias() {
        return depDB.getDependencias();
    }
    
    public Map<Integer, Encomenda> getEncomendas() {
        return encDB.getEncomendas();
    }
    
    // Retorna ArrayList com os nomes (PKs) das componentes incompatíveis com componente passada como argumento
    public ArrayList<String> getComponentesIncompativeis(String componente) {
        ArrayList<String> ret = new ArrayList<>();
        Map<Integer, Incompatibilidade> incompatibilidades = getIncompatibilidades();
        
        for(Incompatibilidade incompatibilidade : incompatibilidades.values()) {
            String componente_1 = incompatibilidade.getComponente1();
            String componente_2 = incompatibilidade.getComponente2();
            if(componente.equals(componente_1)) 
                ret.add(componente_2);
            else if (componente.equals(componente_2)) 
                ret.add(componente_1);
        }
        return ret;
    }
    
    // Retorna ArrayList com os nomes (PKs) das componentes da qual a componente passada como argumento depende
    public ArrayList<String> getDependenciasComponente(String componente) {
        ArrayList<String> ret = new ArrayList<>();
        Map<Integer, Dependencia> dependencias = getDependencias();
        
        for(Dependencia dependencia : dependencias.values()) {
            String componente_1 = dependencia.getComponente();
            String componente_dependente = dependencia.getComponenteDependente();
            if(componente.equals(componente_dependente)) 
                ret.add(componente_1);
        }
        return ret;
    }
    
    public int adicionarConfiguracao(double preco, String modeloCarro, String emailFuncionario) {
        return this.confDB.adicionarConfiguracao(preco, modeloCarro, emailFuncionario);
    }
    
    public void adicionarComponenteConfiguracao(int idConfiguracao, String nomeComponente) {
        this.confDB.adicionarComponenteConfiguracao(idConfiguracao, nomeComponente);
    }
    
    public void adicionarEncomenda(int nifCliente, String nomeCliente, int contactoCliente, int idConfiguracao) {
        this.encDB.adicionarEncomenda(nifCliente, nomeCliente, contactoCliente, idConfiguracao);
    }
}
