/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import data.DAO_Componente;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rps
 */
public class GestaoComponentes {
    private DAO_Componente cDB;
    
    public GestaoComponentes() {
        this.cDB = new DAO_Componente();
    }
    
    public Map<String, Componente> getComponentes() {
        return cDB.getComponentes();
    }
    
    public ArrayList<String> getCategorias(String detalhe) {
        ArrayList<String> categorias = new ArrayList<>();
        Map<String, Componente> componentes = getComponentes();
        String categoria, detalheAux;
        for(Componente componente : componentes.values()) {
            categoria = componente.getCategoria();
            detalheAux = componente.getDetalhe();
            if(detalheAux.equals(detalhe)) categorias.add(categoria);
        }
        return categorias;
    }
    
    public ArrayList<String> getTiposDetalhesPacote(String idPacote, int opcional, String detalhe) {
        ArrayList<String> categorias = new ArrayList<>();
        Map<String, Componente> componentes = getComponentes();
        String categoria, idPacoteAux, detalheAux;
        int opcionalAux;
        for(Componente componente : componentes.values()) {
            categoria = componente.getCategoria();
            idPacoteAux = componente.getIdPacote();
            detalheAux = componente.getDetalhe();
            opcionalAux = componente.getOpcional();
            if(idPacoteAux.equals(idPacote) && detalheAux.equals(detalhe) && (opcionalAux == opcional)) 
                categorias.add(categoria);
        }
        return categorias;
    }
    
    public ArrayList<String> getTiposDetalhes(int opcional, String detalhe) {
        ArrayList<String> categorias = new ArrayList<>();
        Map<String, Componente> componentes = getComponentes();
        String categoria,detalheAux;
        int opcionalAux;
        for(Componente componente : componentes.values()) {
            categoria = componente.getCategoria();
            detalheAux = componente.getDetalhe();
            opcionalAux = componente.getOpcional();
            if(detalheAux.equals(detalhe) && (opcionalAux == opcional)) 
                categorias.add(categoria);
        }
        return categorias;
    }
    
    public ArrayList<String> getNomesDetalhesPacote(String idPacote) {
        ArrayList<String> nomes = new ArrayList<>();
        Map<String, Componente> componentes = getComponentes();
        String nome, idPacoteAux;
        for(Componente componente : componentes.values()) {
            nome = componente.getNome();
            idPacoteAux = componente.getIdPacote();
            if(idPacoteAux.equals(idPacote))
                nomes.add(nome);
        }
        return nomes;
    }
    
    public ArrayList<String> getNomesDetalhesCategoria(String categoria, int opcional, String detalhe) {
        ArrayList<String> nomes = new ArrayList<>();
        Map<String, Componente> componentes = getComponentes();
        String nome, categoriaAux, detalheAux;
        int opcionalAux;
        for(Componente componente : componentes.values()) {
            nome = componente.getNome();
            categoriaAux = componente.getCategoria();
            detalheAux = componente.getDetalhe();
            opcionalAux = componente.getOpcional();
            if(detalheAux.equals(detalhe) && (opcionalAux == opcional) && (categoriaAux.equals(categoria))) 
                nomes.add(nome);
        }
        return nomes;
    }
    
    public void adicionarStock(String nome, double preco, int stock, int opcional, String detalhe, String categoria) {
        cDB.adicionarStock(nome, preco, stock, opcional, detalhe, categoria);
    }
}
