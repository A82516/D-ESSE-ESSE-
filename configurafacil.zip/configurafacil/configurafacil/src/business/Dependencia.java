/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Dependencia {
    private int idDependencia;
    private String componente;
    private String componente_dependente;
    
    public Dependencia() {
        this.idDependencia = 0;
        this.componente = "";
        this.componente_dependente = "";
    }
    
    public Dependencia(int idDependencia, String componente, String componente_dependente) {
        this.idDependencia = idDependencia;
        this.componente = componente;
        this.componente_dependente = componente_dependente;
    }
    
    public int getIdDependencia() {
        return this.idDependencia;
    }
    
    public String getComponente() {
        return componente;
    }
    
    public String getComponenteDependente() {
        return componente_dependente;
    }
}
