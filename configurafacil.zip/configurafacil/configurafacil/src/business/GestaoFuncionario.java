/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import data.DAO_Funcionario;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rps
 */
public class GestaoFuncionario {
    private DAO_Funcionario fDB;
    
    public GestaoFuncionario() {
        this.fDB = new DAO_Funcionario();
    }
    
    public Map<String, Funcionario> getFuncionarios() {
        return fDB.getFuncionarios();
    }
    
    public void registarUtilizador(String email, String password, int tipo) {
        fDB.registarUtilizador(email, password, tipo);
    }
    
    public String getEmail(String email) {
        return fDB.getEmail(email);
    }
    
    public String getPassword(String email) {
        return fDB.getPassword(email);
    }
    
    public int getTipo(String email) {
        return fDB.getTipo(email);
    }
}
