/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import data.DAO_Pacote;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rps
 */
public class GestaoPacotes {
    private DAO_Pacote pDB;
    
    public GestaoPacotes() {
        this.pDB = new DAO_Pacote();
    }
    
    public Map<String, Pacote> getPacotes() {
        return pDB.getPacotes();
    }
}
