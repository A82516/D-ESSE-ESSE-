/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;
import java.util.Map;


public class SistemaConfiguraFacil {
    
    private GestaoFuncionario gestaoFuncionarios;
    private GestaoComponentes gestaoComponentes;
    private GestaoPacotes gestaoPacotes;
    private GestaoCarros gestaoCarros;
    private GestaoConfiguracoes gestaoConfiguracoes;
    private String emailUtilizadorAtual;
    
    public SistemaConfiguraFacil() {
        this.gestaoFuncionarios = new GestaoFuncionario();
        this.gestaoComponentes = new GestaoComponentes();
        this.gestaoPacotes = new GestaoPacotes();
        this.gestaoCarros = new GestaoCarros();
        this.gestaoConfiguracoes = new GestaoConfiguracoes();
        this.emailUtilizadorAtual = "";
    }
    
    public Map<String, Carro> consultarCarros() {
        return this.gestaoCarros.consultarCarros();
    }
    
    public Carro consultarCarro(String modelo) {
        return this.gestaoCarros.consultarCarros().get(modelo);
    } 
    
    public Map<String, Componente> consultarComponentes() {
        return this.gestaoComponentes.getComponentes();
    }
    
    public Componente consultarComponente(String nome) {
        return this.gestaoComponentes.getComponentes().get(nome);
    }
    
    public ArrayList<String> consultarCategorias(String detalhe) {
        return this.gestaoComponentes.getCategorias(detalhe);
    }
    
    public Map<String, Pacote> consultarPacotes() {
        return this.gestaoPacotes.getPacotes();
    }
    
    public Pacote consultarPacote(String nome) {
        return this.gestaoPacotes.getPacotes().get(nome);
    }
    
    public ArrayList<String> consultarTiposDetalhesPacote(String idPacote, int opcional, String detalhe) {
        return this.gestaoComponentes.getTiposDetalhesPacote(idPacote, opcional, detalhe);
    }
    
    public ArrayList<String> consultarTiposDetalhes(int opcional, String detalhe) {
        return this.gestaoComponentes.getTiposDetalhes(opcional, detalhe);
    }
    
    public ArrayList<String> consultarNomesDetalhesPacote(String idPacote) {
        return this.gestaoComponentes.getNomesDetalhesPacote(idPacote);
    }
    
    public ArrayList<String> consultarNomesDetalhesCategoria(String categoria, int opcional, String detalhe) {
        return this.gestaoComponentes.getNomesDetalhesCategoria(categoria, opcional, detalhe);
    }
    
    public ArrayList<String> consultarComponentesIncompativeis(String componente) {
        return this.gestaoConfiguracoes.getComponentesIncompativeis(componente);
    }
    
    public ArrayList<String> consultarDependencias(String componente) {
        return this.gestaoConfiguracoes.getDependenciasComponente(componente);
    }
    
    public int iniciarSessao(String email, String password, String tipo){
        int valid = 0;
        
        if(tipo.equals("Funcionário")) {
            String emailFuncionario = gestaoFuncionarios.getEmail(email);
            String pass = gestaoFuncionarios.getPassword(email);
            int tipoAux = gestaoFuncionarios.getTipo(email);
            if(emailFuncionario.equals(email) && password.equals(pass) && tipoAux == 0){
                valid = 1;
                this.emailUtilizadorAtual = email;
            }
        } else if (tipo.equals("Gerente")) {
            String emailFuncionario = gestaoFuncionarios.getEmail(email);
            String pass = gestaoFuncionarios.getPassword(email);
            int tipoAux = gestaoFuncionarios.getTipo(email);
            if(emailFuncionario.equals(email) && password.equals(pass) && tipoAux == 1){
                valid = 1;
                this.emailUtilizadorAtual = email;
            }
        }
        return valid;
    }
    
    public ArrayList<Double> consultarOrcamento(ArrayList<String> componentesPretendidas) {
        ArrayList<Double> ret = new ArrayList<>();
        double preco = consultarCarro(componentesPretendidas.get(0)).getPreco();
        ret.add(preco);
        
        for(int i = 1; i < componentesPretendidas.size(); i++) {
            preco = consultarComponente(componentesPretendidas.get(i)).getPreco();
            ret.add(preco);
        } 
        return ret;
    }
    
    public double calcularTotalOrcamento(String idPacote, ArrayList<Double> precoComponentes) {
        double total = 0;
        double desconto = consultarPacote(idPacote).getDesconto();
        
        for(Double preco : precoComponentes)
            total += preco;
        
        total = total * (1 - desconto);
        return total;
    }
    
    public void adicionarStockCarro (String modelo, double preco, int stock) {
        this.gestaoCarros.adicionarStock(modelo, preco, stock);
    }
    
    public void adicionarStockComponente(String nome, double preco, int stock, int opcional, String detalhe, String categoria) {
        this.gestaoComponentes.adicionarStock(nome, preco, stock, opcional, detalhe, categoria);
    }
    
    public void registarUtilizador(String email, String password, String tipo) {
        int tipoAux = -1;
        if(tipo.equals("Funcionário")) tipoAux = 0;
        else if(tipo.equals("Gerente")) tipoAux = 1;
        this.gestaoFuncionarios.registarUtilizador(email, password, tipoAux);
    }
    
    public String getEmailUtilizadorAtual() {
        return this.emailUtilizadorAtual;
    }
    
    public boolean adicionarEncomenda(String emailFuncionario, String nomeCliente, int nifCliente, int contactoCliente, ArrayList<String> componentes, double preco) {
        String modeloCarro = componentes.get(0);
        Componente componente;
        String nome, detalhe, categoria;
        double precoComponente;
        int stock, opcional;
        
        
        int idConfiguracao = this.gestaoConfiguracoes.adicionarConfiguracao(preco, modeloCarro, emailFuncionario);
        
        for(int i = 1; i < componentes.size(); i++) {
            componente = consultarComponente(componentes.get(i));
            nome = componente.getNome();
            precoComponente = componente.getPreco();
            stock = componente.getStock();
            opcional = componente.getOpcional();
            detalhe = componente.getDetalhe();
            categoria = componente.getCategoria();
            if(stock == 0) return false;
            this.gestaoConfiguracoes.adicionarComponenteConfiguracao(idConfiguracao, componentes.get(i));
            this.adicionarStockComponente(nome, precoComponente, stock - 1, opcional, detalhe, categoria);
        }
        
        this.gestaoConfiguracoes.adicionarEncomenda(nifCliente, nomeCliente, contactoCliente, idConfiguracao);
        
        if(idConfiguracao == 0) return false;
        else return true;
        
    }
    
    public Map<Integer, Encomenda> consultarEncomendas() {
        return this.gestaoConfiguracoes.getEncomendas();
    }
}
