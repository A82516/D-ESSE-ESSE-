/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author rps
 */
public class Encomenda {
    private int idEncomenda;
    private int nifCliente;
    private String nomeCliente;
    private int contactoCliente;
    private int idConfiguracao;
    
    public Encomenda() {
        this.idEncomenda = 0;
        this.nifCliente = 0;
        this.nomeCliente = "";
        this.contactoCliente = 0;
        this.idConfiguracao = 0;
    }
    
    public Encomenda(int idEncomenda, int nifCliente, String nomeCliente, int contactoCliente, int idConfiguracao) {
        this.idEncomenda = idEncomenda;
        this.nifCliente = nifCliente;
        this.nomeCliente = nomeCliente;
        this.contactoCliente = contactoCliente;
        this.idConfiguracao = idConfiguracao;
    }   
    
    public int getIdEncomenda() {
        return this.idConfiguracao;
    }
    
    public int getNifCliente() {
        return this.nifCliente;
    } 
    
    public String getNomeCliente() {
        return this.nomeCliente;
    } 
    
    public int getContactoCliente() {
        return this.contactoCliente;
    } 
    
    public int getIdConfiguracao() {
        return this.idConfiguracao;
    } 
}
