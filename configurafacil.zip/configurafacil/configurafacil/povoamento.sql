SET SQL_SAFE_UPDATES = 0;





INSERT INTO Funcionario
	(email, palavra_passe, tipo)
    VALUES
    ('funcionario@gmail.com','funcionario', 0),
    ('gerente@gmail.com', 'gerente', 1);
   
INSERT INTO Carro
	(Modelo,Preco,Stock)
    VALUES
    ('Audi', 30000, 20),
    ('Volkswagen', 20000, 40),
    ('Toyota', 15000, 40),
    ('Alfa Romeo', 25000, 25),
    ('Seat', 12500, 30),
    ('Mercedes', 45000, 20),
    ('Porsche', 75000,  10);
    
   
INSERT INTO Pacote
	(Nome, Desconto)
    VALUES
    ('Base', 0.0),
    ('Conforto', 0.20), 
    ('Desportivo', 0.10),
    ('Híbrido', 0.25),
    ('Cábrio', 0.15),
    ('Turismo', 0.10);

   
INSERT INTO Componente
	(Nome, Preco, Stock, idPacote, Opcional, Detalhe, Categoria)
	VALUES
    ('Pintura Preto Mate', 2500, 1000, NULL, 0, 'Exterior', 'Pintura'),
	('Pintura Dourado', 2500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Prateado', 2500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Branco', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Cinzento', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Azul', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Vermelho', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Castanho', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Bege', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Verde', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Pintura Amarelo', 1500, 1000, NULL, 0, 'Exterior', 'Pintura'),
    ('Jantes Liga Leve', 2000, 1000, NULL, 0, 'Exterior', 'Jantes'),
    ('Jantes Fundidas', 1500, 1000, NULL, 0, 'Exterior', 'Jantes'),
    ('Jantes Forjadas', 1500, 1000, NULL, 0, 'Exterior', 'Jantes'),
    ('Jantes Modulares', 3000, 1000, NULL, 0, 'Exterior', 'Jantes'),
    ('Pneus Base', 0, 1000, NULL, 0, 'Exterior', 'Pneus'),
    ('Pneus Conforto', 500, 1000, 'Conforto', 0, 'Exterior', 'Pneus'),
    ('Pneus Desportivos', 2000, 1000, 'Desportivo', 0, 'Exterior', 'Pneus'),
    ('Pneus Turismo', 1500, 1000, 'Turismo', 0, 'Exterior', 'Pneus'),
    ('Motor Base', 3000, 1000, NULL, 0, 'Exterior', 'Motor'),
    ('Motor Eficiente', 4500, 1000, NULL, 0, 'Exterior', 'Motor'),
    ('Motor Verde', 6000, 1000, NULL, 0, 'Exterior', 'Motor'),
    ('Motor Desportivo', 5000, 1000, 'Desportivo', 0, 'Exterior', 'Motor'),
    ('Motor Híbrido', 4500, 1000, 'Híbrido', 0, 'Exterior', 'Motor'),
    ('Motor Elétrico', 6000, 1000, NULL, 0, 'Exterior', 'Motor'),
    ('Vidros Escurecidos', 450, 1000, NULL, 1, 'Exterior', 'Vidros'),
    ('Vidros Duplos', 750, 1000, NULL, 1, 'Exterior', 'Vidros'),
    ('Para-choques Base', 0, 1000, NULL, 1, 'Exterior', 'Para-choques'),
    ('Para-choques Reforçados', 500, 1000, NULL, 1, 'Exterior', 'Para-choques'),
    ('Para-choques Desportivos', 1000, 1000, 'Desportivos', 1, 'Exterior', 'Para-choques'),
    ('Teto Descapotável', 750, 1000, 'Cábrio', 1, 'Exterior', 'Teto'),
    ('Teto de Abrir', 500, 1000, NULL, 1, 'Exterior', 'Teto'),
    ('Estofos Base', 0, 1000, NULL, 0, 'Interior', 'Estofos'),
    ('Estofos em Pele', 1250, 1000, NULL, 0, 'Interior', 'Estofos'),
    ('Pacote de Luzes Base', 0, 1000, NULL, 0, 'Interior', 'Pacote de Luzes'),
    ('Pacote de Luzes Dinâmico', 4000, 1000, NULL, 0, 'Interior', 'Pacote de Luzes'),
    ('Painel GPS', 250, 1000, NULL, 1, 'Interior', 'Painel'),
    ('Painel Interativo', 500, 1000, NULL, 1, 'Interior', 'Painel');

INSERT INTO Incompatibilidade
	(Componente_1,Componente_2,idIncompatibilidade)
	VALUES
	('Pintura Preto Mate', 'Pintura Dourado', 1),
    ('Pintura Preto Mate', 'Pintura Prateado', 2),
    ('Pintura Preto Mate', 'Pintura Branco', 3),
    ('Pintura Preto Mate', 'Pintura Cinzento', 4),
    ('Pintura Preto Mate', 'Pintura Azul', 5),
    ('Pintura Preto Mate', 'Pintura Vermelho', 6),
    ('Pintura Preto Mate', 'Pintura Castanho', 7),
    ('Pintura Preto Mate', 'Pintura Verde', 8),
    ('Pintura Preto Mate', 'Pintura Amarelo', 9),
    ('Pintura Dourado', 'Pintura Prateado', 10),
    ('Pintura Dourado', 'Pintura Branco', 11),
    ('Pintura Dourado', 'Pintura Cinzento', 12),
    ('Pintura Dourado', 'Pintura Azul', 13),
    ('Pintura Dourado', 'Pintura Vermelho', 14),
    ('Pintura Dourado', 'Pintura Castanho', 15),
    ('Pintura Dourado', 'Pintura Verde', 16),
    ('Pintura Dourado', 'Pintura Amarelo', 17),
    ('Pintura Prateado', 'Pintura Branco', 18),
    ('Pintura Prateado', 'Pintura Cinzento', 19),
    ('Pintura Prateado', 'Pintura Azul', 20),
    ('Pintura Prateado', 'Pintura Vermelho', 21),
    ('Pintura Prateado', 'Pintura Castanho', 22),
    ('Pintura Prateado', 'Pintura Verde', 23),
    ('Pintura Prateado', 'Pintura Amarelo', 24),
    ('Pintura Branco', 'Pintura Cinzento', 25),
    ('Pintura Branco', 'Pintura Azul', 26),
    ('Pintura Branco', 'Pintura Vermelho', 27),
    ('Pintura Branco', 'Pintura Castanho', 28),
    ('Pintura Branco', 'Pintura Verde', 29),
    ('Pintura Branco', 'Pintura Amarelo', 30),
    ('Pintura Cinzento', 'Pintura Azul', 31),
    ('Pintura Cinzento', 'Pintura Vermelho', 32),
    ('Pintura Cinzento', 'Pintura Castanho', 33),
    ('Pintura Cinzento', 'Pintura Verde', 34),
    ('Pintura Cinzento', 'Pintura Amarelo', 35),
    ('Pintura Azul', 'Pintura Vermelho', 36),
    ('Pintura Azul', 'Pintura Castanho', 37),
    ('Pintura Azul', 'Pintura Verde', 38),
    ('Pintura Azul', 'Pintura Amarelo', 39),
    ('Pintura Vermelho', 'Pintura Castanho', 40),
    ('Pintura Vermelho', 'Pintura Verde', 41),
    ('Pintura Vermelho', 'Pintura Amarelo', 42),
    ('Pintura Castanho', 'Pintura Verde', 43),
    ('Pintura Castanho', 'Pintura Amarelo', 44),
    ('Pintura Verde', 'Pintura Amarelo', 45);

INSERT INTO Dependencia
	(Componente,Componente_Dependente,idDependencia)
    VALUES
    ('Motor Base', 'Pintura Azul', 1),
    ('Painel Interativo', 'Motor Elétrico', 2);